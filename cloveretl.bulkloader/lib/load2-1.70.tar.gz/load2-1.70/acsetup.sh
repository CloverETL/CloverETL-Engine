:	"@(#)$Id: acsetup.sh,v 1.1 2003/02/05 19:44:32 root Exp $"
#
# Steps required to AutoConfigure Informix's ESQL/C
#


rm -f aclocal.m4
#libtoolize --force
aclocal -I .
autoheader
#automake -a --foreign
autoconf


#!/bin/sh
# supported compilers: MSVS: cl, Borland: bcc32, GNU: GCC, lcc-win32
#COMPILER=cl;
#COMPILER=DM;
#COMPILER=bcc32;
#COMPILER=gcc
#configure are using only following options of gcc:
# --version, -v, -V, -c , -g, -DDDL_EXPORT -DPIC, -o , -E, -D, -I, -L
# eqivalents in other compilers:
# cl) <err>, <err>, <err>, /c, /Zi, ?, /Fo(obj) or /Fe(exe), /E, /D, /I, <env>
#bcc32) <err>, <err>, <err>, -c, -v, ?, -e, cpp32, -D, -L
#sc)    <err>, <err>, <err>, -c, -g, ?, -o, -e, -D, -I, ?
#lc) -v, -v, -v, -c , -g2, ?, -Fo(obj) or -o(exe), -E, -D, -I, 

#export INCLUDE;
#export LIB;
echo $WIN_CC >>aa.log
echo $* >>aa.log
case "$WIN_CC" in
  cl)
#    LIB='D:/Programs/DevStudio/vc/lib';
    echo $* >>cl_config.log
    my_cmd=`echo $* | sed -e 's/--version/\/YYYYYY/' \
                          -e 's/-v/\/YYYYYY/' \
                          -e 's/-V/\/YYYYYY/' \
                          -e 's/-c/\/c/' \
                          -e 's/-g/\/Zi/' \
                          -e 's/-o /\/Fe/' \
                          -e 's/-E/\/E/' \
                          -e 's/-D/\/D/' \
                          -e 's/-I/\/I/' `

    echo $my_cmd >>cl_config.log
    eval "cl.exe $my_cmd"
    exit
    ;;
  bcc32)
#Needs bcc32.cfg, ilink32.cfg, path to Bin
    my_cmd=`echo $* | sed -e 's/--version/-YYYYYY/' \
                          -e 's/-v/-YYYYYY/' \
                          -e 's/-V/-YYYYYY/' \
                          -e 's/-g/-v/' \
                          -e 's/-o /-o/' \
                          -e 's/-E//' `
     echo $* >>bcc_config.log
     echo $my_cmd >>bcc_config.log;
     test1=`echo $* | sed 's/.*\-E.*/XXX/g'`
     if test "X${test1}" = XXXX
     then
             eval "cpp32 $my_cmd"
             exit
     else
             echo $test1 >>bcc_config.log
             eval "bcc32 $my_cmd"
             exit
     fi
     ;;
  gcc)
    eval "gcc $*"
    echo $* >>gcc_config.log
    echo "\n#\n" >>gcc_config.log
    exit
    ;;
  lc)
    echo $* >>lcc_config.log
    if test `echo $* | sed -e 's/.*\-E.*/XXX/' ` = XXX
    then
#             cl /E $my_cmd
        my_cmd=`awk -vDMARGS="$*" 'BEGIN {
			N=split(DMARGS, args);
			for (i = 1; i <= N; i++)
			  if (args[i] == "-E") {
			    todel = i;
			    break;
			    }
			filename=args[N];
                        print "lc -c -E "filename"; "  "cat "  gensub(".c", ".i", "g", filename);
			}'`;
             echo $my_cmd >>lcc_config.log
             eval $my_cmd
             exit
     else
        my_cmd=`echo $* | sed -e 's/-g/-g2/' \
                              -e 's/-o /-Fe/' `
        echo $my_cmd >>lcc_config.log
        eval "lc $my_cmd"
        exit
     fi
    
    exit
    ;;
  *)
    echo "Unimplemented compiler variety";
    exit 1;
esac

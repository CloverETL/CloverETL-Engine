/******************************************************************************
*
* Procedure for creating temporary files
*
* Author: Robert Sosnowski, Robert.Sosnowski@bzwbk.pl
*
* Version 1.70, 17-10-2005
*
* Copyright (c) 2001 - 2007. All Rights Reserved.
*
* Permission granted to use & distribute for free. Changes in source code
* require Author's acceptance.
*
* This software can be used only at your own risk. Author is not responsible 
* for any damage caused by using this software.
* 
******************************************************************************/


#include <stdlib.h>
#include <stdio.h>
/* #define DEBUG_ALLOC 1 */

char *creatmpfile(void);
char *creatmpfile2(char *prefix, char *extension);
void *load2_calloc(size_t nmemb, size_t size);
void *load2_malloc(size_t size, char *file1, int line1);
void load2_free(void *ptr, char *file1, int line1);
#ifdef HAVE_SYS_STAT_H
#include <sys/stat.h>
#else
#include "load2cfg.h"
#endif
int fseek8(FILE *f, off_t offset, int origin);
off_t ftell8(FILE *f);
mint off_t2int8(off_t offset, ifx_int8_t *offset2);
char * off_t2hex(off_t offset);

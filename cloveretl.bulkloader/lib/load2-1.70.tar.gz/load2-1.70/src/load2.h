/******************************************************************************
*
* Prototypes for library of Informix database loading functions
*
* Author: Robert Sosnowski, Robert.Sosnowski@bzwbk.pl
*
* Version 1.70, 17-10-2005
*
* Copyright (c) 2001 - 2007. All Rights Reserved.
*
* Permission granted to use & distribute for free. Changes in source code
* require Author's acceptance.
*
* This software can be used only at your own risk. Author is not responsible 
* for any damage caused by using this software.
* 
******************************************************************************/

#define TBLNAME_SIZE 128 /* 18 in old servers */
#define USERNAME_SIZE 32 /* 8 in old servers */
#define TBLNAMEFULL_SIZE (3 * TBLNAME_SIZE + USERNAME_SIZE + sizeof("@:''."))
                     /* A table name can be: database@server:"owner".table */
#define ERR_BUF_SIZE 200

#define MAXMEMBLOB 32767

typedef int (*onlogerror_lpt)(const char * srcfile, const int pline,
                              const char *errstr, const long int sqlcode,
                              const long int isamcode, const char *ifx_str,
                              const unsigned long int rownum,
                              const unsigned long int processed,
                              const int os_errno, const void *logfile,
                              const int verbosity, const int urgency);


/* please do not reference directly structure members,
 * this structure is not hidden only to help compiler
 * to discover inconsistencies */
struct loader_handle_struct {
/* private: */
  char * insstmt2;
  char * insstmt;
  char * updstmt;
  char * delstmt;
  char * selstmt;
  char * fname;
  char delim;
  int batchsize;
  int usecursor;
  int usecommit;
  int maxerrors;
  int verbosity;
  /* default values: 0 - no messages even in case of error
                    10 - only critical error messages
                    20 - all other error messages
		    30 - standard messages
		    40 - verbose messages
		    50 - debugging messages */
  unsigned long int loaded_rows;
  unsigned long int inserted_rows;
  unsigned long int updated_rows;
  unsigned long int deleted_rows;
  unsigned long int inserted_rows0;
  unsigned long int updated_rows0;
  unsigned long int deleted_rows0;
  const void *logfile;
  int errcnt;
  char errstr[ERR_BUF_SIZE];

  char tablename[TBLNAMEFULL_SIZE+1];
  int fieldsnum;
  int unload_type;
  int extra_fields;
  char escapechar;
  void *datahandle;
  char *datahandleoptions;

  int (*oninit)(const char *fname, const char *tablename, const int batchsize,
                void **handle, const void *logfile, const int fieldsnum,
                const char *insstmt2, onlogerror_lpt onlogerror,
                const int verbosity, const char *datahandleoptions);

  int (*onrow)(const char *fname, const char *tablename, const void *handle,
               const unsigned long int rownum, const unsigned long int loaded,
               const unsigned long int inserted,
               const unsigned long int updated,
               const unsigned long int deleted);

  int (*onbatch)(const char *fname, const char *tablename, const void *handle,
                 const unsigned long int rownum, const unsigned long int loaded,
                 const unsigned long int inserted,
                 const unsigned long int updated,
                 const unsigned long int deleted,
                 const void *logfile, onlogerror_lpt onlogerror,
                 const int verbosity);

  int (*onfinish)(const char *fname, const char *tablename, const void *handle,
                  const unsigned long int rownum,
                  const unsigned long int rownum2,
                  const unsigned long int inserted,
                  const unsigned long int updated,
                  const unsigned long int deleted,
                  const void *logfile, onlogerror_lpt onlogerror,
                  const int verbosity);

  int (*onreadfield)(const void *fd, const int sqltype, const int4 sqlxid,
                     const char *filename, char **dstbuf,
                     const unsigned int maxdstbuf, const char delim,
                     const char escapech, int * eol,  int * sqlind,
                     const unsigned long int rownum,
                     const unsigned long int loaded, const int fieldnum,
                     const char *fieldname, const int max_fld_name,
                     char *fieldname2, const void *logfile,
                     onlogerror_lpt onlogerror, const int verbosity,
                     const char *datahandleoptions);

  void (*oncleanup)(const char *fname, void *handle, const void *logfile,
                    onlogerror_lpt onlogerror, const int verbosity,
                    const char *datahandleoptions);

  onlogerror_lpt onlogerror;

  int (*oncrlf)(const void *fd, const char *filename,
                const unsigned long int rownum, const unsigned long int loaded,
                const int fields_number, const int bequiet,
                const char escapech, const void *logfile,
                onlogerror_lpt onlogerror, const int verbosity,
                const char *datahandleoptions);

  int (*onrecordbegin)(const void *fd, const char *filename,
                       const unsigned long int rownum,
                       const unsigned long int loaded, const int fields_number,
                       const int bequiet, const char escapech,
                       const void *logfile,
                       onlogerror_lpt onlogerror, const int verbosity,
                       const char *datahandleoptions);

  int (*is_critical)(const long int sqlcode, const long int isamcode,
                     const int errtype, const int errcnt, const int maxerors,
                     int *errinc);

  int (*onblobfree)(loc_t *simple_lo, const void *logfile,
                    onlogerror_lpt onlogerror, int verbose);

  short uploadmode;
  short uploadmode2;
  char *keycols2;
  int *indicators; /* not 'short' because there were leakage problems
                      - only while using insert cursor and only in 
                      some cases (not always) */
  short *nullables;
  short *used_tags;
  short *keycols;
  struct sqlda *ldesc;
  struct sqlda *ludesc;
  struct sqlda *lddesc;
  struct sqlda *lsdesc;
  struct sqlda *lsdesc2;
  int uploadcmd;
  char *recordbuffer;
  unsigned long int rownum;
  unsigned long int rownum2;
  unsigned long int rownum2_old;
  int iscursoropen;
  int isinsidetrans;
  unsigned long int instance_id;
  short blobs;
  short noupdates;
  short noinserts;
};

typedef struct loader_handle_struct loader_handle_t;

int load (const char *insstmt2, const char *fname, const char delim,
          const int batchsize, const int usecursor,
          const int usecommit, const int maxerrors,
          unsigned long int *loaded_rows, const void *logfile,
          int verbosity,
          int (*oninit)(const char *fname, const char *tablename,
                        const int batchsize, void **handle,
                        const void *logfile, const int fieldsnum,
                        const char *insstmt2,
                        onlogerror_lpt onlogerror, const int verbosity,
                        const char *datahandleoptions),
          int (*onrow)(const char *fname, const char *tablename,
                       const void *handle, const unsigned long int rownum,
                       const unsigned long int loaded,
                       const unsigned long int inserted,
                       const unsigned long int updated,
                       const unsigned long int deleted),
          int (*onbatch)(const char *fname, const char *tablename,
                         const void *handle, const unsigned long int rownum,
                         const unsigned long int loaded,
                         const unsigned long int inserted,
                         const unsigned long int updated,
                         const unsigned long int deleted,
                         const void *logfile,
                         onlogerror_lpt onlogerror, const int verbosity),
          int (*onfinish)(const char *fname, const char *tablename,
                          const void *handle, const unsigned long int rownum,
                          const unsigned long int rownum2,
                          const unsigned long int inserted,
                          const unsigned long int updated,
                          const unsigned long int deleted,
                          const void *logfile,
                          onlogerror_lpt onlogerror, const int verbosity),
          int (*onreadfield)(const void *fd, const int sqltype,
                             const int4 sqlxid,
                             const char *filename, char **dstbuf,
                             const unsigned int maxdstbuf, const char delim,
                             const char escapech, int * eol,
                             int * sqlind, const unsigned long int rownum,
                             const unsigned long int loaded, const int fieldnum,
                             const char * fieldname, const int max_fld_name,
                             char *fieldname2, const void *logfile,
                             onlogerror_lpt onlogerror, const int verbosity,
                             const char *datahandleoptions),
          void (*oncleanup)(const char *fname, void *handle,
                            const void *logfile,
                            onlogerror_lpt onlogerror, const int verbosity,
                            const char *datahandleoptions),
          onlogerror_lpt onlogerror,
          int (*oncrlf)(const void *fd, const char *filename,
                        const unsigned long int rownum,
                        const unsigned long int loaded,
                        const int fields_number, const int bequiet,
                        const char escapech, const void *logfile,
                        onlogerror_lpt onlogerror, const int verbosity,
                        const char *datahandleoptions),
          int (*onrecordbegin)(const void *fd, const char *filename,
                               const unsigned long int rownum,
                               const unsigned long int loaded,
                               const int fields_number, const int bequiet,
                               const char escapech, const void *logfile,
                               onlogerror_lpt onlogerror, const int verbosity,
                               const char *datahandleoptions),
          int (*is_critical)(const long int sqlcode, const long int isamcode,
                             const int errtype, const int errcnt,
                             const int maxerors, int *errinc));
 
int loader_setdatahandlename(loader_handle_t *loader_handle, const char *fname);

int loader_setdatahandleoptions(loader_handle_t *loader_handle, const char *datahandleoptions);

void loader_setdelimiter(loader_handle_t *loader_handle, const char delim);

void loader_setbatchsize(loader_handle_t *loader_handle, const int batchsize);

void loader_setusecursor(loader_handle_t *loader_handle, const int usecursor);

void loader_setusecommit(loader_handle_t *loader_handle, const int usecommit);

void loader_setmaxerrors(loader_handle_t *loader_handle, const int maxerrors);

void loader_setverbosity(loader_handle_t *loader_handle, const int verbosity);

void loader_setloghandle(loader_handle_t *loader_handle, const void *logfile);

void loader_setoninit(loader_handle_t *loader_handle,
                      int (*oninit)(const char *fname, const char *tablename,
                                    const int batchsize, void **handle,
                                    const void *logfile, const int fieldsnum,
                                    const char *insstmt2,
                                    onlogerror_lpt onlogerror,
                                    const int verbosity,
                                    const char *datahandleoptions));

void loader_setonrow(loader_handle_t *loader_handle,
                     int (*onrow)(const char *fname, const char *tablename,
                                  const void *handle,
                                  const unsigned long int rownum,
                                  const unsigned long int loaded,
                                  const unsigned long int inserted,
                                  const unsigned long int updated,
                                  const unsigned long int deleted));

void loader_setonbatch(loader_handle_t *loader_handle,
                       int (*onbatch)(const char *fname, const char *tablename,
                                      const void *handle,
                                      const unsigned long int rownum,
                                      const unsigned long int loaded,
                                      const unsigned long int inserted,
                                      const unsigned long int updated,
                                      const unsigned long int deleted,
                                      const void *logfile,
                                      onlogerror_lpt onlogerror,
                                      const int verbosity));

void loader_setonfinish(loader_handle_t *loader_handle,
                        int (*onfinish)(const char *fname,
                                        const char *tablename,
                                        const void *handle,
                                        const unsigned long int rownum,
                                        const unsigned long int rownum2,
                                        const unsigned long int inserted,
                                        const unsigned long int updated,
                                        const unsigned long int deleted,
                                        const void *logfile,
                                        onlogerror_lpt onlogerror,
                                        const int verbosity));

void loader_setonreadfield(loader_handle_t *loader_handle,
                           int (*onreadfield)(const void *fd, const int sqltype,
                                              const int4 sqlxid,
                                              const char *filename, char **dstbuf,
                                              const unsigned int maxdstbuf,
                                              const char delim,
                                              const char escapech, int * eol,
                                              int * sqlind,
                                              const unsigned long int rownum,
                                              const unsigned long int loaded,
                                              const int fieldnum,
                                              const char * fieldname,
                                              const int max_fld_name,
                                              char *fieldname2,
                                              const void *logfile,
                                              onlogerror_lpt onlogerror,
                                              const int verbosity,
                                              const char *datahandleoptions));

void loader_setoncleanup(loader_handle_t *loader_handle,
                         void (*oncleanup)(const char *fname, void *handle,
                                           const void *logfile,
                                           onlogerror_lpt onlogerror,
                                           const int verbosity,
                                           const char *datahandleoptions));

void loader_setonlogerror(loader_handle_t *loader_handle,
                          onlogerror_lpt onlogerror);

void loader_setoncrlf(loader_handle_t *loader_handle,
                      int (*oncrlf)(const void *fd, const char *filename,
                                    const unsigned long int rownum,
                                    const unsigned long int loaded,
                                    const int fields_number, const int bequiet,
                                    const char escapech, const void *logfile,
                                    onlogerror_lpt onlogerror,
                                    const int verbosity,
                                    const char *datahandleoptions));

void loader_setonrecordbegin(loader_handle_t *loader_handle,
                             int (*onrecordbegin)(const void *fd,
                                                  const char *filename,
                                                  const unsigned long int rownum,
                                                  const unsigned long int loaded,
                                                  const int fields_number,
                                                  const int bequiet,
                                                  const char escapech,
                                                  const void *logfile,
                                                  onlogerror_lpt onlogerror,
                                                  const int verbosity,
                                                  const char *datahandleoptions));

void loader_setiscritical(loader_handle_t *loader_handle,
                          int (*is_critical)(const long int sqlcode,
                                             const long int isamcode,
                                             const int errtype,
                                             const int errcnt,
                                             const int maxerors,
                                             int *errinc));

void loader_setblobfree(loader_handle_t *loader_handle,
                        int (*onblobfree)(loc_t *simple_lo, const void *logfile,
                                          onlogerror_lpt onlogerror,
                                          int verbose));

void loader_setunload_type(loader_handle_t *loader_handle, const int unload_type);

void loader_setextrafields(loader_handle_t *loader_handle, const int extra_fields);

void loader_setescapechar(loader_handle_t *loader_handle, const char escapechar);

void loader_setuploadmode(loader_handle_t *loader_handle, const short uploadmode);

void loader_setuploadmode2(loader_handle_t *loader_handle, const short uploadmode2);

int loader_setkeycols(loader_handle_t *loader_handle, const char *collist);



char * loader_getstmt(loader_handle_t *loader_handle);

char * loader_getdatahandlename(loader_handle_t *loader_handle);

char * loader_getdatahandleoptions(loader_handle_t *loader_handle);

char loader_getdelimiter(loader_handle_t *loader_handle);

int loader_getbatchsize(loader_handle_t *loader_handle);

int loader_getusecursor(loader_handle_t *loader_handle);

int loader_getusecommit(loader_handle_t *loader_handle);

int loader_getmaxerrors(loader_handle_t *loader_handle);

int loader_getverbosity(loader_handle_t *loader_handle);

unsigned long int loader_getloadedrows(loader_handle_t *loader_handle);

int loader_geterrcnt(loader_handle_t *loader_handle);

char *loader_geterrstr(loader_handle_t *loader_handle);

char * loader_getablename(loader_handle_t *loader_handle);

int loader_getfieldsnum(loader_handle_t *loader_handle);

int loader_getunload_type(loader_handle_t *loader_handle);

int loader_getfieldtypeext(loader_handle_t *loader_handle, const int fieldnum);

int loader_getextrafields(loader_handle_t *loader_handle);

char loader_getescapechar(loader_handle_t *loader_handle);


loader_handle_t *loader_create (void);
int loader_setstmt(loader_handle_t *loader_handle, const char *insstmt2);
int loader_prepare(loader_handle_t *loader_handle);
int loader_open(loader_handle_t *loader_handle);
int loader_readfield(loader_handle_t *loader_handle, int *fieldnum,
                     void *buf, unsigned long int buf_size,
                     unsigned long int *bytesread, int *all_records,
                     char *fieldname, const int maxfieldname, int *emptyread,
                     int *all_fields, int *badrecord, int *sqlind);
int loader_beforerow(loader_handle_t *loader_handle);
int loader_putfield(loader_handle_t *loader_handle, const int fieldnum,
                    const void *buffer, const int buflen, const int sqlind,
                    int *badrecord);
int loader_putrecord(loader_handle_t *loader_handle);
int loader_close(loader_handle_t *loader_handle);
int loader_free(loader_handle_t *loader_handle);
int loader_getfieldnum(loader_handle_t *loader_handle, const char *fieldname);
/* return value: 0 .. n-1 field number, -1 extra column containing command 
   for loadinc, -2 hard error (cleanup), -3 soft error (continue)
*/
int loader_getfieldtype(loader_handle_t *loader_handle, const int fieldnum);

int simple_load (const char * insstmt2, const char *fname);
int convert_keycols(loader_handle_t *loader_handle);


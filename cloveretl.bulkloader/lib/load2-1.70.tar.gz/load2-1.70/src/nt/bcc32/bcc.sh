export PATH=/cygdrive/d/Programs/Borland/Bcc55/bin:$PATH
#./configure cc=bcc32

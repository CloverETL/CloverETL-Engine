/******************************************************************************
*
* Prototypes for library of Informix database unload functions
*
* Author: Robert Sosnowski, Robert.Sosnowski@bzwbk.pl
*
* Version 1.70, 17-10-2005
*
* Copyright (c) 2001 - 2007. All Rights Reserved.
*
* Permission granted to use & distribute for free. Changes in source code
* require Author's acceptance.
*
* This software can be used only at your own risk. Author is not responsible 
* for any damage caused by using this software.
* 
******************************************************************************/

#define TBLNAME_SIZE 128 /* 18 in old servers */
#define USERNAME_SIZE 32 /* 8 in old servers */
#define TBLNAMEFULL_SIZE (3 * TBLNAME_SIZE + USERNAME_SIZE + sizeof("@:''."))
                     /* A table name can be: database@server:"owner".table */
#define ERR_BUF_SIZE 200


#define FLDSIZE 40
#define BUF1_SIZE 32767
#define MAXMEMBLOB 32767

/* #define NOBINARY_FLAG 1 */


typedef int (*onlogerror_upt)(const char * srcfile, const int pline,
                              const char *errstr, const long int sqlcode,
                              const long int isamcode, const char *ifx_str,
                              const unsigned long int rownum,
                              const unsigned long int processed,
                              const int os_errno, const void *logfile,
                              const int verbosity, const int urgency);

/* please do not reference directly structure members,
 * this structure is not hidden only to help compiler
 * to discover inconsistencies */
struct unl_handle_struct {
/* private: */
  char * slctstmt2;
  char *fname;
  char delim;
  int batchsize;
  int verbosity;
  /* default values: 0 - no messages even in case of error
                    10 - only critical error messages
                    20 - all other error messages
		    30 - standard messages
		    40 - verbose messages
		    50 - debugging messages */

  unsigned long int unloaded_rows;
  const void *logfile;
  char errstr[ERR_BUF_SIZE];

  char tablename[TBLNAMEFULL_SIZE+1];
  int fieldsnum;
  char escapechar;
  void *datahandle;
  char *datahandleoptions;
  void *tmp_blob_file;
 
  int (*oninit)(char *fname, const char *tablename, int batchsize,
                void **handle, char *escapech, const void *logfile,
                int fieldsnum, char *slctstmt2,
                onlogerror_upt onlogerror, int verbose,
                const char *datahandleoptions);
  int (*onrow)(char *fname, const char *tablename, void *handle,
               unsigned long int rownum);
  int (*onbatch)(char *fname, const char *tablename, void *handle,
                 unsigned long int rownum,
                 const void *logfile,
                 onlogerror_upt onlogerror, int verbose);
  int (*onfinish)(char *fname, char *tablename, void *handle,
                  unsigned long int rownum, const void *logfile,
                  onlogerror_upt onlogerror, int verbose);
  int (*onwritefield)(void *fd, int sqltype, int4 sqlxid, char *filename,
                      const char *src, const unsigned int buflen,
                      char delim, char escapech,
                      short int sqlind, unsigned long int rownum,
                      int fieldnum, char *fieldname, const void *logfile,
                      onlogerror_upt onlogerror, int verbose,
                      const char *datahandleoptions,
                      void *fieldstate);
  void (*oncleanup)(char *fname, void *handle, const void *logfile,
                    onlogerror_upt onlogerror, int verbose,
                    const char *datahandleoptions);
  onlogerror_upt onlogerror;
  int (*oncrlf)(void *fd, char *filename, unsigned long int rownum,
                const void *logfile,
                onlogerror_upt onlogerror, int verbose,
                const char *datahandleoptions);
  int (*onrecordbegin)(void *fd, char *filename,
	               unsigned long int rownum, const void *logfile,
                       onlogerror_upt onlogerror, int verbose,
                       const char *datahandleoptions);
  int (*onblobfree)(loc_t *simple_lo, const void *logfile,
                    onlogerror_upt onlogerror, int verbose);
  mint (*openblob)(loc_t *loc, mint flag, mint bsize);
  mint (*closeblob)(loc_t *loc);
  mint (*writeblob)(loc_t *loc, char *buffer, mint bufflen);

  int *indicators;
  struct sqlda *udesc;
  char *recordbuffer;
  unsigned long int rownum;
/*  unsigned long int rownum2;
  unsigned long int rownum2_old; */
  int iscursoropen;
  unsigned long int instance_id;
  short blobs;
  short fetcharray;
  int fetarrsize;
  int fetarridx; /* 0..fetarrsiz-1 */
  int *typmsizes;
  void **fieldstates;
};

typedef struct unl_handle_struct unl_handle_t;

#ifdef HAVE_SYS_STAT_H
#include <sys/stat.h>
#else
#include "load2cfg.h"
#endif

struct slob_handle_struct {
  char filename[256];
  off_t offset;
  off_t size;
};

typedef struct slob_handle_struct slob_handle_t;
                     
int unload (const char * slctstmt2, const char *fname, const char delim,
            const int batchsize, unsigned long int *unloaded_rows,
            const void *logfile, const int verbosity,
            const char *tablename,
            int (*oninit)(char *fname, const char *tablename, int batchsize,
                          void **handle, char *escapech, const void *logfile,
                          int fieldsnum, char *slctstmt2,
                          onlogerror_upt onlogerror, int verbose,
                          const char *datahandleoptions),
            int (*onrow)(char *fname, const char *tablename, void *handle,
                         unsigned long int rownum),
            int (*onbatch)(char *fname, const char *tablename, void *handle,
                           unsigned long int rownum,
                           const void *logfile,
                           onlogerror_upt onlogerror, int verbose),
            int (*onfinish)(char *fname, char *tablename, void *handle,
                            unsigned long int rownum,
                            const void *logfile,
                            onlogerror_upt onlogerror, int verbose),
            int (*onwritefield)(void *fd, int sqltype, int4 sqlxid, char *filename,
                                const char *src, const unsigned int buflen,
                                char delim, char escapech,
                                short int sqlind, unsigned long int rownum,
                                int fieldnum, char *fieldname, const void *logfile,
                                onlogerror_upt onlogerror, int verbose,
                                const char *datahandleoptions,
                                void *fieldstate),
            void (*oncleanup)(char *fname, void *handle, const void *logfile,
                              onlogerror_upt onlogerror, int verbose,
                              const char *datahandleoptions),
            onlogerror_upt onlogerror,
            int (*oncrlf)(void *fd, char *filename, unsigned long int rownum,
                          const void *logfile,
                          onlogerror_upt onlogerror,
                          int verbose,
                          const char *datahandleoptions),
            int (*onrecordbegin)(void *fd, char *filename,
                                 unsigned long int rownum, const void *logfile,
                                 onlogerror_upt onlogerror, int verbose,
                                 const char *datahandleoptions)
);

int unl_setdatahandlename(unl_handle_t *unl_handle, const char *fname);

int unl_setdatahandleoptions(unl_handle_t *unl_handle, const char *datahandleoptions);

void unl_setdelimiter(unl_handle_t *unl_handle, const char delim);

void unl_setbatchsize(unl_handle_t *unl_handle, const int batchsize);

void unl_setverbosity(unl_handle_t *unl_handle, const int verbosity);

void unl_setloghandle(unl_handle_t *unl_handle, const void *logfile);

void unl_setfetcharray(unl_handle_t *unl_handle, const short fetcharray);

void unl_setoninit(unl_handle_t *unl_handle,
                   int (*oninit)(char *fname, const char *tablename,
                                 int batchsize, void **handle, char *escapech,
                                 const void *logfile, int fieldsnum, char *slctstmt2,
                                 onlogerror_upt onlogerror, int verbose,
                                 const char *datahandleoptions));

void unl_setonrow(unl_handle_t *unl_handle,
                  int (*onrow)(char *fname, const char *tablename, void *handle,
                               unsigned long int rownum));

void unl_setonbatch(unl_handle_t *unl_handle,
                    int (*onbatch)(char *fname, const char *tablename,
                                   void *handle, unsigned long int rownum,
                                   const void *logfile,
                                   onlogerror_upt onlogerror, int verbose));

void unl_setonfinish(unl_handle_t *unl_handle,
                     int (*onfinish)(char *fname, char *tablename, void *handle,
                     unsigned long int rownum, const void *logfile,
                     onlogerror_upt onlogerror, int verbose));

void unl_setonwritefield(unl_handle_t *unl_handle,
                        int (*onwritefield)(void *fd, int sqltype, int4 sqlxid,
                        char *filename, const char *src,
                        const unsigned int buflen, char delim,
                        char escapech, short int sqlind,
                        unsigned long int rownum, int fieldnum,
                        char *fieldname, const void *logfile,
                        onlogerror_upt onlogerror, int verbose,
                        const char *datahandleoptions,
			void *fieldstate));

void unl_setoncleanup(unl_handle_t *unl_handle,
                      void (*oncleanup)(char *fname, void *handle,
                                        const void *logfile,
                                        onlogerror_upt onlogerror,
                                        int verbose,
                                        const char *datahandleoptions));

void unl_setonlogerror(unl_handle_t *unl_handle,
                          onlogerror_upt onlogerror);

void unl_setoncrlf(unl_handle_t *unl_handle,
                   int (*oncrlf)(void *fd, char *filename,
                                 unsigned long int rownum,
                                 const void *logfile,
                                 onlogerror_upt onlogerror,
                                 int verbose,
                                 const char *datahandleoptions));

void unl_setonrecordbegin(unl_handle_t *unl_handle,
                          int (*onrecordbegin)(void *fd, char *filename,
                          unsigned long int rownum, const void *logfile,
                          onlogerror_upt onlogerror, int verbose,
                          const char *datahandleoptions));

void unl_setblobfree(unl_handle_t *unl_handle,
                     int (*onblobfree)(loc_t *simple_lo, const void *logfile,
                                       onlogerror_upt onlogerror,
                                       int verbose));

void unl_setescapechar(unl_handle_t *unl_handle, const char escapechar);

void unl_settablename(unl_handle_t *unl_handle, const char *tablename);
  
char * unl_getstmt(unl_handle_t *unl_handle);

char * unl_getdatahandlename(unl_handle_t *unl_handle);

char * unl_getdatahandleoptions(unl_handle_t *unl_handle);

char unl_getdelimiter(unl_handle_t *unl_handle);

int unl_getbatchsize(unl_handle_t *unl_handle);

int unl_getverbosity(unl_handle_t *unl_handle);

unsigned long int unl_getunloadedrows(unl_handle_t *unl_handle);

char *unl_geterrstr(unl_handle_t *unl_handle);

char *unl_getablename(unl_handle_t *unl_handle);

int unl_getfieldsnum(unl_handle_t *unl_handle);

char unl_getescapechar(unl_handle_t *unl_handle);

short unl_getfetcharray(unl_handle_t *unl_handle);

unl_handle_t *unl_create (void);
int unl_setstmt(unl_handle_t *unl_handle, const char *selstmt);
int unl_prepare(unl_handle_t *unl_handle);
int unl_open(unl_handle_t *unl_handle);
int unl_writefield(unl_handle_t *unl_handle, const int fieldnum,
                 const void *buffer, const int buflen, const int sqlind,
                 void *fieldstate);
int unl_beforerow(unl_handle_t *unl_handle);
int unl_afterrow(unl_handle_t *unl_handle);
int unl_getfield(unl_handle_t *unl_handle, const int fieldnum,
                 void *buffer, const unsigned int buflen,
                 unsigned long int *bytesread, int *sqlind);
int unl_getrecord(unl_handle_t *unl_handle, int *all_records);
int unl_close(unl_handle_t *unl_handle);
int unl_free(unl_handle_t *unl_handle);

/* return value: 0 .. n-1 field number, -1 extra column containing command 
   for loadinc, -2 hard error (cleanup), -3 soft error (continue)
*/
int unl_getfieldtype(unl_handle_t *unl_handle, const int fieldnum);

int simple_unload (const char * slctstmt2, const char *fname);

